// console.group("qtn1")
// for(let i=0;i<=100;i++){
//     if(i%3===0){
//         console.log(i+"fizz")
//     }
//     if(i%5===0){
//         console.log(i+"buzz")
//     }
//     if(i%3===0 && i%5===0)
//     {console.log(i+ "fizzbuzz")}
//     }
//     console.groupEnd("qtn1")

//     console.group("qtn2")
//     const student={
//         name:"Helsinki",
//         age:24,projects:{
//             diceGame:"two player dice game using java script"
//         }
//     }
//      const {name,age,projects:{diceGame}}=student
//     console.log(name,age,diceGame)
//     console.groupEnd("qtn2")

//     console.group("qtn3")
//     let shoppingList=['soap','shampoo','oil','rice','fruits']
//     let shoppingBasket=String(shoppingList.push('dress','cooker'))
//     console.log(shoppingBasket)
//     console.groupEnd("qtn3")

// //     console.group("qtn4")
// //     console.groupEnd("qtn4")

//   console.group("qtn5")
//     let x=prompt("what is the sale")
//     function func(){
//         if(x<=5000)
//         return (x*0.02);
//         if(x>=5000 && x<=10000)
//         return ((5000*0.02)+((x-5000)*0.05))
//     if(x>=10000 && x<=20000)
// return((5000*0.02)+(5000*0.05)+((x-10000)*0.07));
// if(x>2000)
// return (((5000*0.02)+(5000*0.05)+(10000*0.07)+((x-20000)*0.1)))
//     }console.log(func())
//     console.groupEnd("qtn5")

    // console.group('qtn6')
    // while(true){
    // let x=Number(prompt("enter the number greater than hundere"))

    // if(x>100){
    //     console.log(x)
    //     break;
    // }
    // else(x<100)
    // {
    //     prompt("enter the number greater than hundere")
    //     continue
    // }}
    // console.groupEnd('qtn6')

    // console.group("qtn7")
    // let val=Number(prompt('enter the number'))
    // for(let i=2;i<val;i++)
    // {
    //     if(i%2!==0)
    //     {
    //         console.log(`${i}`)
    //     }
    // }
    // console.groupEnd('qtn7')


    // function ask(question,yes,no){
    //     if(confirm(question))yes()
    //     else no();
    // }
    // ask(
    //     'do you agree?',
    //     function() {alert('you agreed')},function()
    //     {
    //         alert('you canceled the execution')
    //     }
    // )
    let ask=(question,yes,no)=>{
        if(confirm(question))yes()
        else no();
    }
    ask('do you agree?',yes=>{alert('you agreed')},no=>{alert('you canceled the execution')})